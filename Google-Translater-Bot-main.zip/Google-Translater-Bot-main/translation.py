class Translation(object):

    START_MSG = """👋Hello {}\n\n I am simple Google Translater Bot \n I can translate any language to your desired language"""

    TRANSLATED_MSG = """Choose The language From here That I Want to Translate.👇"""

    ABOUT_MSG = """🤖 Bot : Google Translator\n\n👨‍🎓 Credit : @PR0FESS0R_99\n\n🎙️ Language : Python3\n\n📚 Lybrary : Pyrogram v1.2.9\n\n🛑 Server : Heroku\n\n📱 Build :V0.3"""

