# Google-Translater-Bot


  </a>
</p>
<p align="center">
  <a href="https://github.com/PR0FESS0R-99/Google-Translater-Bot/stargazers">
    <img src="https://img.shields.io/github/stars/PR0FESS0R-99/Google-Translater-Bot?style=social">

  </a>
  
  <a href="https://github.com/PR0FESS0R-99/Google-Translater-Bot/fork">
    <img src="https://img.shields.io/github/forks/PR0FESS0R-99/Google-Translater-Bot?label=Fork&style=social">

  </a>  
</p>

<img src="https://github.com/Mo-Tech-MRK-YT/Mo-Tech-MRK-YT/blob/main/gifs/Hi.gif" width="20px"> Hey [Mo Tech](https://Telegram.dog/Mo_Tech_Group),

I am simple Google Translater Bot.
I can translate any language to you selected language
 
  Team [Mo Tech](https://Telegram.dog/Mo_Tech_YT)

# Deploy To Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/PR0FESS0R-99/Google-Translater-Bot)

### Credits

* [Pr0fess0r-99](https://github.com/PR0FESS0R-99) 
* [lntechnical2](https://github.com/lntechnical2) Translater mode added
* [Shahsad-klr](https://github.com/shahsad-klr) Added Back To Language Button
